import instaloader
import tweepy
import numpy as np
from tensorflow.keras.models import model_from_json
from tensorflow.keras import Sequential
from tensorflow.keras.layers import Dense
from numpy.random import seed
from django.shortcuts import render
from django.http import HttpResponse

# For Tweepy (Ensure you have correct Bearer Token)
Bearer_Token = "YOUR_TWITTER_BEARER_TOKEN"  # Replace with your actual token
seed(1)

def Index(request):
    return render(request, "fpd/detect.html")


def Detect(request):
    try:
        status = int(request.POST['status'])
        followers = int(request.POST['followers'])
        friends = int(request.POST['friends'])
        fav = int(request.POST['fav'])
        lang_num = int(request.POST['lang_num'])
        listed_count = int(request.POST['listed_count'])

        geo = float(request.POST['geo'])  # Convert geo to float (0.0 or 1.0)
        pic = int(request.POST['pic'])

        # Load the trained model
        json_file = open('fpd/model.json', 'r')
        loaded_model_json = json_file.read()
        json_file.close()

        # Load the model
        loaded_model = model_from_json(loaded_model_json)
        loaded_model.load_weights("fpd/model.h5")

        # Prepare input features
        features = np.array([[status, followers, friends, fav, lang_num, listed_count, geo, pic]])
        prediction = loaded_model.predict(features)
        prediction = prediction[0]

        # Threshold the prediction
        if (prediction > 0.5) * 1 == 1:
            result = "The Profile is Fake"
        else:
            result = "The Profile is real"

        return render(request, 'fpd/detect.html', {'msg': result})

    except Exception as e:
        return render(request, 'fpd/detect.html', {'msg': f"An error occurred: {str(e)}"})


def twitter(request):
    try:
        input_username = str(request.POST['inputusername'])
        input_username = input_username.removeprefix('https://twitter.com/').removeprefix('http://twitter.com/').removeprefix('twitter.com/')

        def getClient():
            return tweepy.Client(bearer_token=Bearer_Token)

        def getUserInfo(client, username):
            return client.get_user(username=username, user_fields='public_metrics,location,pinned_tweet_id,profile_image_url')

        client = getClient()
        user_info = getUserInfo(client, input_username)

        public_metrics = user_info.data.public_metrics
        status = int(public_metrics['tweet_count'])
        followers = int(public_metrics['followers_count'])
        friends = int(public_metrics['following_count'])
        fav = str(user_info.data.pinned_tweet_id)

        # Fallback for fav value if not available
        fav = int(friends / 3 - 7) if fav == 'None' else int(friends / 2 + 3)

        lang_num = 5  # Assuming constant
        listed_count = int(public_metrics['listed_count'])

        geo = 1 if user_info.data.location else 0
        pic = 0 if user_info.data.profile_image_url == 'https://abs.twimg.com/sticky/default_profile_images/default_profile_normal.png' else 1

        features = np.array([[status, followers, friends, fav, lang_num, listed_count, geo, pic]])

        # Load the trained model
        json_file = open('fpd/model.json', 'r')
        loaded_model_json = json_file.read()
        json_file.close()

        loaded_model = model_from_json(loaded_model_json)
        loaded_model.load_weights("fpd/model.h5")

        prediction = loaded_model.predict(features)
        prediction = prediction[0]

        # Threshold the prediction
        if (prediction > 0.5) * 1 == 1:
            result = "The Profile is Fake"
        else:
            result = "The Profile is real"

        return render(request, 'fpd/twitter.html', {'msg': result})

    except tweepy.TweepError as e:
        return render(request, 'fpd/twitter.html', {'msg': f"Twitter API error: {str(e)}"})
    except Exception as e:
        return render(request, 'fpd/twitter.html', {'msg': f"An error occurred: {str(e)}"})


def insta(request):
    return render(request, 'fpd/instagram.html')


def instagram(request):
    try:
        L = instaloader.Instaloader()

        # Provide your session cookies if necessary, or use instaloader CLI to login
        L.load_session_from_file("your_username")  # Replace with your username

        input_username = str(request.POST['inputusername'])
        input_username = input_username.removeprefix('https://instagram.com/').removeprefix('http://instagram.com/').removeprefix('instagram.com/')

        profile = instaloader.Profile.from_username(L.context, input_username)

        # Collecting user data
        status = int(profile.mediacount)
        followers = int(profile.followers)
        friends = int(profile.followees)
        fav = int(profile.has_viewable_story)
        lang_num = 5  # Assuming constant

        listed_count = int(friends / 3 - 7) if fav == 1 else int(friends / 2 + 3)
        geo = 0  # Default as not geo-tagged
        pic = 1  # Assume they have a profile picture

        features = np.array([[status, followers, friends, fav, lang_num, listed_count, geo, pic]])

        # Load the trained model
        json_file = open('fpd/model.json', 'r')
        loaded_model_json = json_file.read()
        json_file.close()

        loaded_model = model_from_json(loaded_model_json)
        loaded_model.load_weights("fpd/model.h5")

        prediction = loaded_model.predict(features)
        prediction = prediction[0]

        # Threshold the prediction
        if (prediction > 0.5) * 1 == 1:
            result = "The Profile is Fake"
        else:
            result = "The Profile is real"

        return render(request, 'fpd/instagram.html', {'msg': result})

    except instaloader.exceptions.ProfileNotExistsException:
        return render(request, 'fpd/instagram.html', {'msg': "The specified Instagram profile does not exist."})
    except Exception as e:
        return render(request, 'fpd/instagram.html', {'msg': f"An error occurred: {str(e)}"})
